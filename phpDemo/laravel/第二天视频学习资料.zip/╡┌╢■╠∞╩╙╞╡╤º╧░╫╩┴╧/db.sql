-- 创建数据库
create database gcwapp;
-- 使用gcwapp数据库
use gcwapp;
-- 设置编码格式
set names gbk;
-- 创建数据表
create table gcw_article(
  id mediumint unsigned not null auto_increment,
  title varchar(40) not null,
  description varchar(255),
  content text,
  author varchar(20),
  addtime int,
  primary key(id)
) engine = myisam default charset=utf8;
-- 创建数据表
create table gcw_admin(
  id tinyint unsigned not null auto_increment,
  username varchar(20) not null,
  password char(32) not null,
  primary key(id)
) engine = myisam default charset=utf8;
-- 插入测试数据
insert into gcw_admin values (null,'admin',md5('admin888'));